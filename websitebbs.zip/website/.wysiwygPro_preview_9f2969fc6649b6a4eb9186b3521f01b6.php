<?php
if ($_GET['randomId'] != "bta_1YITJHFfs_EIricZm4aH0j4YgCa7WdFHSzxaOcAWtd4kYht9WKoNC9a9aLAB") {
    echo "Access Denied";
    exit();
}

// display the HTML code:
echo stripslashes($_POST['wproPreviewHTML']);

?>  
