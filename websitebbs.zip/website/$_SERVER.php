<?php
echo $_SERVER['HTTP_USER_AGENT'];
?>

My Android browser Output:

Mozilla/5.0 (Linux; U; Android 2.1-update1; en-in; HTC_Wildfire_A3333 Build/ERE27) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari