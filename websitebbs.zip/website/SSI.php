<?php
require_once('/home/mallic/public_html/forums/SSI.php');
#require_once('D:/server/wamp/www/SMF3/SSI.php');
?>