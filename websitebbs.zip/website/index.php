<?php
include('user_agent.php'); // Redirecting to mobile site
// brainbreadsource.com data
?>
<?php

$ssi_guest_access = false;

// Include the SSI file.
require('SSI.php');

?>

<!DOCTYPE html>
<!--[if lt IE 7 ]> <html class="ie ie6 no-js" lang="en"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie ie7 no-js" lang="en"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie ie8 no-js" lang="en"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie ie9 no-js" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--><html class="no-js" lang="en"><!--<![endif]-->

<!-- Made by Jamie Batchelor, updated by Johan Ehrendahl -->

    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 

        <title>BrainBread: Source</title>

        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="" />
        <meta name="keywords" content="bbs, gaming, mod, dev, bb," />
        <meta name="author" content="bbs" />

        <link rel="shortcut icon" href="favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/style1.css" />
		<link rel="stylesheet" href="assets/stylesheets/arthref.css">
		<script type="text/javascript" src="js/modernizr.custom.86080.js"></script>
		
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="assets/javascripts/socialShare.min.js"></script>
<script src="assets/javascripts/socialProfiles.min.js"></script>
<script>
	$(document).ready(function () {

		$('.shareSelector').socialShare({
			social: 'facebook,twitter,google,pinterest,stumbleupon,delicious,friendfeed,digg,linkedin',
			whenSelect: true,
			selectContainer: '.shareSelector',
			blur: true
		});

		$('.followSelector').socialProfiles({
			animation: 'chain',
			blur: true,
			facebook: 'brainbreadsource',
			google: 'communities/115468461317920228444',
			twitter: '@bbsdevs',
			steam: 'BrainBread'
		});
	});
</script>
		
		
		<script>

var html5_audiotypes={ //define list of audio file extensions and their associated audio types. Add to it if your specified audio file isn't on this list:
	"mp3": "audio/mpeg",
	"mp4": "audio/mp4",
	"ogg": "audio/ogg",
	"wav": "audio/wav"
}

function createsoundbite(sound){
	var html5audio=document.createElement('audio')
	if (html5audio.canPlayType){ //check support for HTML5 audio
		for (var i=0; i<arguments.length; i++){
			var sourceel=document.createElement('source')
			sourceel.setAttribute('src', arguments[i])
			if (arguments[i].match(/\.(\w+)$/i))
				sourceel.setAttribute('type', html5_audiotypes[RegExp.$1])
			html5audio.appendChild(sourceel)
		}
		html5audio.load()
		html5audio.playclip=function(){
			html5audio.pause()
			html5audio.currentTime=0
			html5audio.play()
		}
		return html5audio
	}
	else{
		return {playclip:function(){throw new Error("Your browser doesn't support HTML5 audio unfortunately")}}
	}
}

//Initialize two sound clips with 1 fallback file each:

var mouseoversound=createsoundbite("sound/stab.ogg", "sound/stab.mp3")
var clicksound=createsoundbite("sound/bite.ogg", "sound/bite.mp3")

</script>

<style>
body,html,div,blockquote,img,label,p,h1,h2,h3,h4,h5,h6,pre,ul,ol,li,dl,dt,dd,form,a,fieldset,input,th,td{border:0;outline:none;margin:0;padding:0;}
ul{list-style:none; line-height: 1.5em;}

body {font: normal 13px Arial, sans-serif;}
h2 {font: normal 26px Arial, sans-serif; padding: 20px 0; margin: 0 0 30px 0;}
.wrap {width: 960px; margin: 0 auto;}
.demo-container {width: 260px; margin: 50px auto;}
.demo-container h4 {font-size: 14px; margin: 0 0 5px 0;}
.clear {clear: both;}
.test {background: #990000;}
.dc-slick-content p {margin-bottom: 1em;}
.dc-slick-content a {color: #fff;}
.tab {color: #fff; font-weight: bold;}

</style>

    </head>
    <body id="page">

        <ul class="cb-slideshow">
            <li><span></span><div><h3></h3></div></li>
            <li><span></span><div><h3></h3></div></li>
            <li><span></span><div><h3></h3></div></li>
            <li><span></span><div><h3></h3></div></li>
            <li><span></span><div><h3></h3></div></li>
            <li><span></span><div><h3></h3></div></li>
        </ul>
        <div class="container">
            <!-- top bar -->
            <div class="c-top">
                <!-- <a href="">
                    <strong>&laquo;...</strong>..
                </a> -->
                <span class="right">
					<div class="col1">
						<section id="twitter_div" class="holder">
							<a class="twitter-timeline" width="246" height="215" href="https://twitter.com/bbsdevs" data-tweet-limit="1" data-chrome="noheader nofooter transparent noborders" data-link-color="red" data-widget-id="278069797697224704">Tweets by @bbsdevs</a>
							<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
						</section>
					</div>
					<a href="http://www.moddb.com/mods/brainbread-source" target="_blank" title="View the BrainBread mod on ModDB"><img src="http://button.moddb.com/popularity/medium/mods/7492.png" alt="BrainBread Source" /></a>
                </span>
                <div class="clr"></div>
            </div><!--/ top bar -->
			<!-- Body Bar -->
            <header>
                <div align="center"><h1><span><img src="img/logo.png"></span></h1>
                <h2>Nobody knows how it started, nobody really knows where...</h2>
				<p class="c-demos">
					<a href="index.php" onclick="clicksound.playclip()" onmouseover="mouseoversound.playclip()">News</a>
					<a href="http://wiki.brainbreadsource.com/index.php?title=BrainBread:_Source_-_The_Team" target="_blank" onclick="clicksound.playclip()" onmouseover="mouseoversound.playclip()">The Team</a>
					<a href="http://forums.brainbreadsource.com/" target="_blank" onclick="clicksound.playclip()" onmouseover="mouseoversound.playclip()">Forums</a>
					<a href="media.html" onclick="clicksound.playclip()" onmouseover="mouseoversound.playclip()">Media</a>
					<a href="http://wiki.brainbreadsource.com/" target="_blank" onclick="clicksound.playclip()" onmouseover="mouseoversound.playclip()">Wiki</a>
					<a href="#" class="btn followSelector" onclick="clicksound.playclip()" onmouseover="mouseoversound.playclip()">Social</a>
				</p>
				</div>
				<!-- News Section w/ YT trailer video -->
				<div  class="newz">
					<?php
					
					// Get the news
					$news_items = ssi_boardNews(20, 3, null, 800, 'array'); // array(boards), number of items, item to start at, number of characters, output method
					// Loop through all items
					foreach ($news_items as $news)
					{
						// Output this item
						echo '
							<div>
								<a href="', $news['href'], '"><h1>', $news['subject'], '</h1></a>
								<div class="smaller">', $news['time'], ' by ', $news['poster']['link'], '</div>

								<div class="post" style="padding: 2ex 0;">', $news['body'], '</div>

								<div class="comment">', $news['link'], $news['locked'] ? '' : ' | ' . $news['comment_link'], '</div>
							</div>';

						// If it isn't the last item, output a <hr />
						if (!$news['is_last'])
							echo '
							<hr style="margin: 2ex 0;" width="100%" />';
					}
					?>
				</div>
				<div class="news-section">
					<div class="news-section-trailer_body">
						<img class="yt-body_trailer" src="img/video-body.png" />
						<div class="yt-content_trailer">
							<iframe id="ytplayer" type="text/html" width="395" height="255" src="https://www.youtube.com/embed/lHSN9SVL4gg?fs=1&modestbranding=1" frameborder="0" allowfullscreen></iframe>
							<!-- <p class="yt-content_trailer-h2">Official Trailer<p> -->
						</div>
					</div>
				</div>

				<div class="news-body"> <!-- Start of news feed 2-->
					<ul class="news-feed">
						<?php
						// Get the news
						$news_items = ssi_boardNews(20, 6, null, 1, 'array'); // array(boards), number of items, item to start at, number of characters, output method
						// Loop through all items
						foreach ($news_items as $news)
						{
							// Output this item
							echo '
								<li class="news-click">
								<p>
									<a href="', $news['href'], '"><h1>', $news['subject'], '</h1></a>
									<span>', $news['time'], ' by ', $news['poster']['link'], '</span>
								</p>
								</li>';
						}
						?>
					</ul>
				</div>
				<!-- End News Section w/ YT trailer video -->
<br />
<br>

				<!-- Footer -->
				<div class="footer">
					<p class="description">
						<a href="http://store.steampowered.com/app/220/" target="_blank">Half-Life 2</a>, <a href="http://store.steampowered.com/about/" target="_blank">Steam</a> are properties of <a href="http://www.valvesoftware.com/" target="_blank">Valve Corporation</a>.
					</p>
					<p class="copyright">
						
<a href="http://source.valvesoftware.com/"><img src="img/footer.png" /></a>

<center><credits> &copy; 2013 BrainBread Source Devs. All rights reserved</credits></center>
					</p>
				</div>
				<!-- End Footer -->
            </header>
			<!-- End Body Bar -->
        </div>
    </body>
</html>